# Platformer — Godot 4.6 (Landscape)

## Key design decisions
- Viewport: **854 × 480** (landscape)
- `window/handheld/orientation = 2` (landscape in project.godot)
- Camera fixed at **(427, 240)** — exact viewport centre, scrolls X only
- Ground at **Y = 440**, platforms **Y = 180–380**, player spawns at **Y = 360**
- Touch buttons anchored to screen bottom using Control anchors, not fixed px positions
- `reload_current_scene()` called via `call_deferred` to avoid signal-callback crash

## Open in Godot 4.6
1. Unzip
2. Godot 4.6 → Import → select `project.godot`
3. F5 to run (arrow keys + space for desktop)

## Android Export
1. Project → Export → Add → Android
2. Set keystore (debug keystore is fine for testing)
3. Enable Touch Screen in preset
4. Export Project → install APK

## Controls
- ◀ ▶ — move (bottom-left)
- ▲ — jump (bottom-right)
- Stomp enemies from above; touch from side = lose a life
- 3 lives total
