extends Node2D

# Viewport: 854 x 480 landscape
# Ground at Y=440, platforms between Y=180 and Y=380
const CHUNK_W    := 700.0
const GROUND_Y   := 440.0
const PLAT_Y_MIN := 180.0
const PLAT_Y_MAX := 380.0

var _gen_x := 0.0
var _rng   := RandomNumberGenerator.new()

var _plat_scene  : PackedScene
var _coin_scene  : PackedScene
var _enemy_scene : PackedScene

func _ready() -> void:
	_plat_scene  = load("res://scenes/Platform.tscn")
	_coin_scene  = load("res://scenes/Coin.tscn")
	_enemy_scene = load("res://scenes/Enemy.tscn")
	_rng.randomize()

	# Wide ground floor
	_spawn_plat(Vector2(-300.0, GROUND_Y), 2800.0, 50.0, true)

	# Two chunks visible immediately
	_gen_chunk(0.0)
	_gen_chunk(CHUNK_W)

func update(cam_x: float) -> void:
	# Spawn ahead
	while _gen_x < cam_x + 1200.0:
		_gen_chunk(_gen_x)

func _gen_chunk(start_x: float) -> void:
	_gen_x = start_x + CHUNK_W
	var x := start_x + 80.0

	while x < start_x + CHUNK_W - 80.0:
		var w := _rng.randf_range(120.0, 220.0)
		var y := _rng.randf_range(PLAT_Y_MIN, PLAT_Y_MAX)

		_spawn_plat(Vector2(x, y), w, 18.0)

		# Coins above platform
		var nc := _rng.randi_range(0, 3)
		for i in nc:
			var cx := x + _rng.randf_range(16.0, w - 16.0)
			_spawn_coin(Vector2(cx, y - 36.0))

		# Enemy on wider platforms
		if w > 160.0 and _rng.randf() > 0.5:
			_spawn_enemy(
				Vector2(x + w * 0.5, y - 26.0),
				x + 18.0,
				x + w - 18.0
			)

		x += w + _rng.randf_range(80.0, 160.0)

func _spawn_plat(pos: Vector2, w: float, h: float, ground := false) -> void:
	var p: StaticBody2D = _plat_scene.instantiate()
	add_child(p)
	p.position = pos
	p.setup(w, h, ground)

func _spawn_coin(pos: Vector2) -> void:
	var c: Area2D = _coin_scene.instantiate()
	add_child(c)
	c.position = pos

func _spawn_enemy(pos: Vector2, left: float, right: float) -> void:
	var e: CharacterBody2D = _enemy_scene.instantiate()
	add_child(e)
	e.position = pos
	e.setup(left, right)
	e.add_to_group("enemy")
