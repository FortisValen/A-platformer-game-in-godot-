extends CharacterBody2D

const SPEED        := 240.0
const JUMP_FORCE   := -500.0
const GRAVITY      := 980.0
const MAX_FALL     := 1200.0
const FALL_DEATH_Y := 520.0

var invincible_timer := 0.0
var blink_timer      := 0.0
var dead             := false
var _jump_queued     := false

signal died
signal enemy_stomped

func _physics_process(delta: float) -> void:
	if dead:
		return

	# Gravity
	if not is_on_floor():
		velocity.y = min(velocity.y + GRAVITY * delta, MAX_FALL)

	# Keyboard input (editor / desktop testing)
	var dir := Input.get_axis("move_left", "move_right")
	if dir != 0.0:
		velocity.x = dir * SPEED

	# Consume queued jump
	if _jump_queued and is_on_floor():
		velocity.y = JUMP_FORCE
	_jump_queued = false

	move_and_slide()

	# Flip sprite toward movement direction
	if velocity.x > 0.1:
		$Sprite.scale.x = 1.0
	elif velocity.x < -0.1:
		$Sprite.scale.x = -1.0

	# Invincibility blink
	if invincible_timer > 0.0:
		invincible_timer -= delta
		blink_timer += delta
		modulate.a = 0.0 if int(blink_timer * 10.0) % 2 == 0 else 1.0
	else:
		modulate.a = 1.0

	# Fell off world
	if position.y > FALL_DEATH_Y:
		die()

# Called every frame by HUD to relay touch direction
func set_move_dir(dir: float) -> void:
	velocity.x = dir * SPEED

func request_jump() -> void:
	if is_on_floor():
		_jump_queued = true

func take_damage() -> void:
	if invincible_timer > 0.0 or dead:
		return
	die()

func die() -> void:
	if dead:
		return
	dead = true
	died.emit()

func stomp_bounce() -> void:
	velocity.y = JUMP_FORCE * 0.5
	enemy_stomped.emit()
