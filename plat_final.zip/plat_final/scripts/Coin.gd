extends Area2D

var base_y := 0.0
var _t     := 0.0

func _ready() -> void:
	base_y = position.y
	body_entered.connect(_on_body_entered)

func _process(delta: float) -> void:
	_t += delta
	position.y = base_y + sin(_t * 3.0) * 5.0

func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("player"):
		get_tree().call_group("game", "on_coin_collected")
		queue_free()
