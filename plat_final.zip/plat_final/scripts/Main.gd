extends Node2D

# Viewport 854x480. Camera fixed at centre (427, 240).
const CAM_START_X  := 427.0
const CAM_Y        := 240.0
const SPAWN_X      := 160.0
const SPAWN_Y      := 360.0   # above ground (ground is at 440)
const SCROLL_BASE  := 100.0
const SCROLL_ACCEL := 4.0

var score        := 0
var coins        := 0
var lives        := 3
var scroll_speed := SCROLL_BASE
var game_over    := false
var elapsed      := 0.0

@onready var player    : CharacterBody2D = $Player
@onready var camera    : Camera2D        = $Camera2D
@onready var world     : Node2D          = $WorldGenerator
@onready var hud       : CanvasLayer     = $HUD
@onready var go_panel  : PanelContainer  = $HUD/GameOverPanel

func _ready() -> void:
	add_to_group("game")
	player.add_to_group("player")
	player.died.connect(_on_player_died)
	hud.connect_player(player)
	go_panel.hide()

	# Set starting positions explicitly — do NOT rely on scene file positions
	player.position = Vector2(SPAWN_X, SPAWN_Y)
	camera.position = Vector2(CAM_START_X, CAM_Y)

	_update_hud()

func _process(delta: float) -> void:
	if game_over:
		return

	elapsed      += delta
	scroll_speed  = SCROLL_BASE + elapsed * SCROLL_ACCEL

	# Only scroll X; Y is fixed
	camera.position.x += scroll_speed * delta
	score = int(camera.position.x * 0.1)

	# Scroll wall — if player falls behind, damage them
	if player.position.x < camera.position.x - 450.0 and not player.dead:
		player.take_damage()

	world.update(camera.position.x)
	_check_enemies()
	_update_hud()

func _check_enemies() -> void:
	if player.dead:
		return
	for child in world.get_children():
		if not child.is_in_group("enemy"):
			continue
		var e := child as CharacterBody2D
		if e == null or e.dead:
			continue
		var d := player.position - e.position
		if abs(d.x) < 24.0 and abs(d.y) < 30.0:
			# Stomp: player falling, player centre above enemy centre
			if player.velocity.y > 0.0 and d.y < -6.0:
				e.die()
				player.stomp_bounce()
				score += 200
			else:
				player.take_damage()

func on_coin_collected() -> void:
	coins += 1
	score += 100

func _on_player_died() -> void:
	lives -= 1
	_update_hud()
	if lives <= 0:
		_show_game_over()
	else:
		_respawn()

func _respawn() -> void:
	await get_tree().create_timer(0.8).timeout
	if game_over:
		return
	player.position     = Vector2(camera.position.x - 300.0, SPAWN_Y)
	player.velocity     = Vector2.ZERO
	player.dead         = false
	player.invincible_timer = 2.0
	player.blink_timer      = 0.0

func _show_game_over() -> void:
	game_over = true
	go_panel.show()
	$HUD/GameOverPanel/VBox/ScoreLabel.text = "SCORE  %d" % score

func _update_hud() -> void:
	hud.update_labels(score, coins, lives)

func _on_restart_button_pressed() -> void:
		get_tree().call_deferred("reload_current_scene")
	
