extends CanvasLayer

var _player     : CharacterBody2D = null
var _left_held  := false
var _right_held := false

func connect_player(p: CharacterBody2D) -> void:
	_player = p

func update_labels(score: int, coins: int, lives: int) -> void:
	$TopBar/ScoreLabel.text = "SCORE  %d" % score
	$TopBar/CoinsLabel.text = "COINS  %d" % coins
	$TopBar/LivesLabel.text = "LIVES  %d" % lives

func _process(_delta: float) -> void:
	if _player == null or _player.dead:
		return
	var dir := 0.0
	if _left_held:
		dir -= 1.0
	if _right_held:
		dir += 1.0
	_player.set_move_dir(dir)

func _on_left_down()  -> void: _left_held  = true
func _on_left_up()    -> void: _left_held  = false
func _on_right_down() -> void: _right_held = true
func _on_right_up()   -> void: _right_held = false

func _on_jump_pressed() -> void:
	if _player and not _player.dead:
		_player.request_jump()
