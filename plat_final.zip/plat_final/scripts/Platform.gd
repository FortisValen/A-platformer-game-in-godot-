extends StaticBody2D

func setup(width: float, height: float, is_ground := false) -> void:
	var shape        := RectangleShape2D.new()
	shape.size        = Vector2(width, height)
	$CollisionShape2D.shape = shape

	var body: ColorRect = $Body
	body.size     = Vector2(width, height)
	body.position = Vector2(-width * 0.5, -height * 0.5)
	body.color    = Color("#1e1040") if is_ground else Color("#2a1a5e")

	var top: ColorRect = $Top
	top.size     = Vector2(width, 4.0)
	top.position = Vector2(-width * 0.5, -height * 0.5)
	top.color    = Color("#4a2fa0") if is_ground else Color("#7a4fff")
