extends CharacterBody2D

const SPEED   := 70.0
const GRAVITY := 980.0

var direction    := 1.0
var patrol_left  := 0.0
var patrol_right := 0.0
var dead         := false

func setup(left: float, right: float) -> void:
	patrol_left  = left
	patrol_right = right

func _physics_process(delta: float) -> void:
	if dead:
		return

	velocity.y = min(velocity.y + GRAVITY * delta, 1200.0)
	velocity.x = direction * SPEED

	if position.x <= patrol_left:
		direction = 1.0
	elif position.x >= patrol_right:
		direction = -1.0

	$Sprite.scale.x = direction
	move_and_slide()

func die() -> void:
	if dead:
		return
	dead = true
	var tw := create_tween()
	tw.tween_property(self, "scale", Vector2(1.8, 0.05), 0.12)
	tw.tween_callback(queue_free)
